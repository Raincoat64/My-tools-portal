import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {LIMITS,analyze,render,qualityCheck} from '../pdf-engine.mjs';
import {validateOptions,validateUnit} from '../protocol.mjs';
import * as mupdf from '../vendor/mupdf/mupdf.js';
const root=new URL('../../',import.meta.url),options=validateOptions({});
const fixture=async name=>new Uint8Array(await fs.readFile(new URL(`tmp/browser-fixtures/${name}.pdf`,root)));
function translations(ir){return Object.fromEntries(ir.units.map(unit=>{const t={unit_id:unit.unit_id,status:'OK',ja:'検証用の翻訳である。'+Object.keys(unit.protected_tokens).join(' ')};return [unit.unit_id,{...t,...validateUnit(unit,t)}];}));}
test('authored complete demo translates all units, with strict QA',async()=>{
  const bytes=new Uint8Array(await fs.readFile(new URL('output/demo/paper_original.pdf',root)));
  const authored=JSON.parse(await fs.readFile(new URL('output/demo/source-translations.json',root),'utf8'));
  const result=await analyze(bytes,options);assert.deepEqual(result.ir.blockers,[]);
  const ts={};for(const u of result.ir.units){let ja=authored[u.original];assert.ok(ja,`Missing authored translation: ${u.original}`);for(const [key,value] of Object.entries(u.protected_tokens))ja=ja.replace(value,key);ts[u.unit_id]={unit_id:u.unit_id,status:'OK',ja};}
  const generated=await render(result.working,result.ir,ts);assert.equal(generated.qa.status,'PASS',JSON.stringify(generated.qa.errors));
  await fs.mkdir(new URL('output/browser-demo/',root),{recursive:true});
  await fs.writeFile(new URL('output/browser-demo/paper_ja.pdf',root),generated.output);
  await fs.writeFile(new URL('output/browser-demo/qa.json',root),JSON.stringify(generated.qa,null,2));
});
for(const kind of ['single','two_column','figures','tables','links','crop','rotated','embedded','footnote','supplement','ligature'])test(`${kind}: preserve content, graphics and geometry`,async()=>{
  const result=await analyze(await fixture(kind),options);assert.deepEqual(result.ir.blockers,[]);
  if(kind==='two_column')assert.equal(result.ir.pages[0].columns,2);
  const generated=await render(result.working,result.ir,translations(result.ir));assert.equal(generated.qa.status,'PASS',JSON.stringify(generated.qa.errors));
  assert.ok(generated.qa.pages.every(p=>p.objects_match&&p.geometry_match&&p.outside_mask_pixel_change<=.001));
});
for(const kind of ['scanned','mixed','hidden','transparent','white','overlap','broken_encoding','three_column','actualtext'])test(`${kind}: unsafe input blocks generation`,async()=>{
  const result=await analyze(await fixture(kind),options);assert.ok(result.ir.blockers.length,`${kind} should block`);
  if(kind==='broken_encoding')assert.ok(result.ir.blockers.some(blocker=>blocker.code==='SOURCE_GLYPH_UNKNOWN_UNICODE'));
  await assert.rejects(()=>render(result.working,result.ir,translations(result.ir)),/ANALYSIS_BLOCKED/);
});
test('active content and annotations are rejected',async()=>{
  for(const kind of ['active','annotation'])await assert.rejects(()=>fixture(kind).then(bytes=>analyze(bytes,options)),/CONTENT_UNSUPPORTED|ANNOTATIONS_UNSUPPORTED/);
});
test('password required and not retained in working PDF',async()=>{
  const bytes=await fixture('encrypted');await assert.rejects(()=>analyze(bytes,options),/PASSWORD_REQUIRED/);
  const result=await analyze(bytes,options,'browser-fixture');assert.ok(result.ir.encrypted_source);
  const doc=mupdf.Document.openDocument(result.working,'application/pdf');assert.equal(doc.needsPassword(),false);doc.destroy();
});
test('overflow never returns an output; corrected text can render',async()=>{
  const result=await analyze(await fixture('single'),options),ts=translations(result.ir),first=result.ir.units[0].unit_id;
  ts[first].ja='長い文章'.repeat(1500)+Object.keys(result.ir.units[0].protected_tokens).join(' ');
  const failed=await render(result.working,result.ir,ts);assert.equal(failed.qa.status,'NEEDS_REVIEW');assert.ok(failed.qa.errors.some(e=>e.code==='LAYOUT_OVERFLOW'));assert.ok(!failed.output);
});
test('render reanalyzes the canonical source and rejects source or IR tampering',async()=>{
  const result=await analyze(await fixture('single'),options),ts=translations(result.ir);
  const changed=result.working.slice();changed[changed.length-1]^=1;
  await assert.rejects(()=>render(changed,result.ir,ts),/SOURCE_HASH_MISMATCH/);
  const tampered=JSON.parse(JSON.stringify(result.ir));tampered.pages[0].regions[0].bbox[0]+=1;
  await assert.rejects(()=>render(result.working,tampered,ts),/IR_STRUCTURE_MISMATCH/);
});
test('decoded image occurrence budget fails before unbounded image work',async()=>{
  const previousPixels=LIMITS.decodedImagePixels,previousOccurrences=LIMITS.imageOccurrences;
  LIMITS.decodedImagePixels=0;LIMITS.imageOccurrences=0;
  try{await assert.rejects(()=>fixture('figures').then(bytes=>analyze(bytes,options)),/PDF_RESOURCE_LIMIT/);}
  finally{LIMITS.decodedImagePixels=previousPixels;LIMITS.imageOccurrences=previousOccurrences;}
});
test('reusing one image object cannot bypass the occurrence budget',async()=>{
  const bytes=await fixture('figures'),doc=mupdf.Document.openDocument(bytes,'application/pdf'),object=doc.findPage(0),original=object.get('Contents'),contents=doc.newArray();
  for(let copy=0;copy<2;copy++){if(original.isArray())original.forEach(value=>contents.push(value));else contents.push(original);}object.put('Contents',contents);
  const saved=doc.saveToBuffer('compress'),repeated=saved.asUint8Array().slice();saved.destroy();object.destroy();doc.destroy();
  const previous=LIMITS.imageOccurrences;LIMITS.imageOccurrences=1;
  try{assert.deepEqual((await analyze(bytes,options)).ir.blockers,[]);await assert.rejects(()=>analyze(repeated,options),/PDF_RESOURCE_LIMIT/);}
  finally{LIMITS.imageOccurrences=previous;}
});
test('XMP content survives working-copy compression and reanalysis',async()=>{
  const doc=mupdf.Document.openDocument(await fixture('single'),'application/pdf');
  doc.getTrailer().get('Root').put('Metadata',doc.addStream('<x:xmpmeta xmlns:x="adobe:ns:meta/"><test>PaperMirror fixture</test></x:xmpmeta>',{Type:'Metadata',Subtype:'XML'}));
  const saved=doc.saveToBuffer(),bytes=saved.asUint8Array().slice();saved.destroy();doc.destroy();
  const result=await analyze(bytes,options),generated=await render(result.working,result.ir,translations(result.ir));assert.equal(generated.qa.status,'PASS',JSON.stringify(generated.qa.errors));assert.ok(result.ir.metadata.xmp);
});
test('QA rejects a color change in a small preserved page number',async()=>{
  const result=await analyze(await fixture('single'),options),generated=await render(result.working,result.ir,translations(result.ir)),doc=mupdf.Document.openDocument(generated.output,'application/pdf');let changedStreams=0;
  doc.findPage(0).get('Contents').forEach(ref=>{const data=ref.readStream();try{const text=data.asString();if(text.includes('[(1)]TJ')){ref.writeStream('q 1 0 0 rg '+text+' Q');changedStreams++;}}finally{data.destroy();}});
  assert.ok(changedStreams);const saved=doc.saveToBuffer('compress'),changed=saved.asUint8Array().slice();saved.destroy();doc.destroy();
  const qa=await qualityCheck(result.working,changed,result.ir,generated.qa.plans);assert.ok(qa.errors.some(e=>e.code==='PRESERVED_TEXT_MISMATCH'));assert.ok(qa.pages[0].outside_mask_pixel_change<=.001);
});
test('QA catches lost translated glyphs and changed preserved content',async()=>{
  const result=await analyze(await fixture('single'),options),generated=await render(result.working,result.ir,translations(result.ir));assert.equal(generated.qa.status,'PASS');
  const doc=mupdf.Document.openDocument(generated.output,'application/pdf'),page=doc.loadPage(0),annotation=page.createAnnotation('Redact');annotation.setRect([45,40,560,90]);page.applyRedactions(false,0,0,0);const saved=doc.saveToBuffer('garbage=3,compress'),changed=saved.asUint8Array().slice();saved.destroy();page.destroy();doc.destroy();
  const qa=await qualityCheck(result.working,changed,result.ir,generated.qa.plans);assert.equal(qa.status,'QA_FAILED');assert.ok(qa.errors.some(e=>e.code==='OUTPUT_TRANSLATION_TEXT_MISMATCH'));
});
