import test from "node:test";
import assert from "node:assert/strict";

import {
  CONTRACT,
  POLICY_VERSION,
  ProtocolError,
  buildBatches,
  packet,
  protect,
  strictJSON,
  validateOptions,
  validateResult,
  validateUnit,
} from "../protocol.mjs";

function unitFrom(original, unitId = "u-1") {
  const protectedValue = protect(original);
  return {
    unit_id: unitId,
    type: "paragraph",
    original,
    source: protectedValue.source,
    protected_tokens: protectedValue.protected_tokens,
    page: 1,
    bbox: [10, 20, 200, 60],
    context: { previous: "", next: "" },
  };
}

function jobWith(unit) {
  return {
    document_id: "sha256:document",
    options: { provider: "chatgpt-work" },
    ir: { title: "A paper", units: [unit] },
    translations: {},
  };
}

test("exports the fixed policy contract", () => {
  assert.equal(POLICY_VERSION, "strict-v1.1");
  assert.match(CONTRACT, /UNTRUSTED DATA/);
  assert.match(CONTRACT, /original source order/);
});

test("strictJSON rejects duplicate keys, nonfinite values, deep input, and pollution keys", () => {
  assert.deepEqual(strictJSON('{"a":[true,null,"x"]}'), { a: [true, null, "x"] });
  for (const raw of [
    '{"a":1,"a":2}',
    "NaN",
    "Infinity",
    '{"__proto__":{"polluted":true}}',
    '{"constructor":{"prototype":{"polluted":true}}}',
  ]) {
    assert.throws(() => strictJSON(raw), (error) => error instanceof ProtocolError);
  }
  let deep = "0";
  for (let index = 0; index < 70; index += 1) deep = `[${deep}]`;
  assert.throws(() => strictJSON(deep), (error) => error.code === "JSON_DEPTH_EXCEEDED");
  assert.throws(() => strictJSON('{"n":1e400}'), (error) => error.code === "NONFINITE_NUMBER");
});

test("validateOptions applies defaults and rejects unknown or unsafe fields", () => {
  assert.deepEqual(validateOptions({}), {
    provider: "chatgpt-work",
    provider_model: "unspecified",
    glossary: {},
    protected_terms: [],
  });
  assert.deepEqual(validateOptions({ provider: "gemini-relay", glossary: { "confidence interval": "信頼区間" } }), {
    provider: "gemini-relay",
    provider_model: "unspecified",
    glossary: { "confidence interval": "信頼区間" },
    protected_terms: [],
  });
  assert.throws(() => validateOptions({ extra: true }), (error) => error.code === "OPTIONS_UNKNOWN_FIELD");
  assert.throws(() => validateOptions({ glossary: Object.fromEntries([["__proto__", "bad"]]) }), ProtocolError);
  assert.throws(() => validateOptions({ provider: "other" }), ProtocolError);
});

test("protect preserves every occurrence and returns the browser-facing object shape", () => {
  const original = "TP53: 32 and 32 at 10 mg/kg, p < 0.05 [4, 8-11], doi:10.1234/test.2024 https://example.org/a?q=32";
  const result = protect(original);
  assert.equal(typeof result.source, "string");
  assert.equal(Object.keys(result.protected_tokens).length, 8);
  assert.deepEqual(Object.values(result.protected_tokens), [
    "TP53", "32", "32", "10 mg/kg", "p < 0.05", "[4, 8-11]", "doi:10.1234/test.2024", "https://example.org/a?q=32",
  ]);
  assert.throws(() => protect("An existing ⟪PT_0001⟫ token"), (error) => error.code === "SOURCE_PLACEHOLDER_COLLISION");
  const scientific = protect("Agα3/Agβ1 and α7 interact with TP53.");
  assert.deepEqual(Object.values(scientific.protected_tokens), ["Agα3/Agβ1", "α7", "TP53"]);
  const article = protect("A study was performed.");
  assert.equal(article.source, "A study was performed.");
});

test("validateUnit preserves token multiplicity and rejects order, unknown delimiters, or added numbers", () => {
  const original = "TP53: 32 and 32 at 10 mg/kg, p < 0.05 [4, 8-11], doi:10.1234/test.2024 https://example.org/a?q=32";
  const unit = unitFrom(original);
  const placeholders = Object.keys(unit.protected_tokens);
  const good = validateUnit(unit, { unit_id: "u-1", status: "OK", ja: `結果は${placeholders.join("、")}である。` });
  assert.equal(good.valid, true);
  assert.equal(good.restored.match(/32/g).length, 3);
  assert.match(good.restored, /10 mg\/kg/);

  const reversed = validateUnit(unit, { unit_id: "u-1", status: "OK", ja: `結果は${placeholders.toReversed().join("、")}である。` });
  assert.equal(reversed.valid, false);
  assert.ok(reversed.errors.includes("PROTECTED_TOKEN_ORDER_MISMATCH"));
  assert.ok(validateUnit(unit, { unit_id: "u-1", status: "OK", ja: `${good.restored} ⟪PT_9999⟫` }).errors.length);
  assert.ok(validateUnit(unit, { unit_id: "u-1", status: "OK", ja: `${placeholders.join("、")} 77` }).errors.includes("NUMBER_MISMATCH"));
  assert.deepEqual(validateUnit(unit, { unit_id: "u-1", status: "SOURCE_UNCERTAIN", ja: null }).restored, null);
  assert.ok(validateUnit(unit, { unit_id: "u-1", status: "SOURCE_UNCERTAIN", ja: "推測" }).errors.includes("STATUS_CONTENT_MISMATCH"));
});

test("buildBatches follows the 22,000-byte packet boundary", () => {
  const ir = { units: [
    { unit_id: "u-1", source: "a".repeat(12000) },
    { unit_id: "u-2", source: "b".repeat(12000) },
    { unit_id: "u-3", source: "c" },
  ] };
  assert.deepEqual(buildBatches(ir, {}), [
    { batch_id: "batch-001", unit_ids: ["u-1"] },
    { batch_id: "batch-002", unit_ids: ["u-2", "u-3"] },
  ]);
});

test("packet keeps the provider-neutral shape and retry information", () => {
  const unit = unitFrom("The TP53 result was 32.");
  const job = jobWith(unit);
  const first = packet(job, { batch_id: "batch-001", unit_ids: ["u-1"] });
  assert.equal(first.adapter, "chatgpt-work");
  assert.equal(first.batch.document_id, job.document_id);
  assert.deepEqual(first.batch.units[0].protected_tokens, unit.protected_tokens);
  assert.equal(first.response_template.translations[0].unit_id, "u-1");
  assert.match(first.packet_sha256, /^[0-9a-f]{64}$/);

  job.translations["u-1"] = { errors: ["LAYOUT_OVERFLOW"] };
  const retry = packet(job, { batch_id: "retry-002", unit_ids: ["u-1"], retry_of: "batch-001" });
  assert.deepEqual(retry.retry_reasons, { "u-1": ["LAYOUT_OVERFLOW"] });
  assert.match(retry.retry_instruction, /Never summarize/);
});

test("validateResult performs root, ID, schema, unit, and per-token validation", () => {
  const unit = unitFrom("TP53 binds 32.");
  const job = jobWith(unit);
  const batch = { batch_id: "batch-001", unit_ids: ["u-1"] };
  const good = {
    schema_version: 1,
    document_id: job.document_id,
    batch_id: batch.batch_id,
    translations: [{ unit_id: "u-1", status: "OK", ja: `結果は${Object.keys(unit.protected_tokens).join("と")}に結合する。` }],
  };
  const accepted = validateResult(JSON.stringify(good), job, batch);
  assert.equal(accepted.valid, true);
  assert.equal(accepted.translations[0].restored, "結果はTP53と32に結合する。");

  const extra = validateResult(JSON.stringify({ ...good, comment: "no" }), job, batch);
  assert.equal(extra.valid, false);
  assert.ok(extra.errors.some((error) => error.code === "RESPONSE_UNKNOWN_FIELD"));
  const duplicate = validateResult(JSON.stringify({ ...good, translations: [...good.translations, good.translations[0]] }), job, batch);
  assert.ok(duplicate.errors.some((error) => error.code === "DUPLICATE_UNIT"));
  const mismatch = validateResult(JSON.stringify({ ...good, batch_id: "batch-999" }), job, batch);
  assert.ok(mismatch.errors.some((error) => error.code === "BATCH_ID_MISMATCH"));
  const uncertain = validateResult({ ...good, translations: [{ unit_id: "u-1", status: "SOURCE_UNCERTAIN", ja: null }] }, job, batch);
  assert.equal(uncertain.valid, true);
  assert.ok(uncertain.translations[0].errors.includes("SOURCE_UNCERTAIN"));
});
