# PaperMirror-JP ブラウザ版

GitHub Pages などの静的配信だけで動く版。PDF の処理は MuPDF.js 1.28.1 / WebAssembly の Web Worker 内で実行します。Python サーバー・AI API キー・レンタルサーバーは不要です。

## GitHub Pages に公開

既存ポータルでの配置先は [My-tools-portal / PaperMirror-JP](https://raincoat64.github.io/My-tools-portal/tools/papermirror-jp/) です。ポータルへ更新を反映する場合は、生成した `_site/` の内容を同リポジトリの `tools/papermirror-jp/` に配置します。以下は単独リポジトリとして配信する場合の手順です。

一番手軽なのは、生成済みの `output/releases/papermirror-pages.zip` を展開し、その中身を専用 GitHub リポジトリのルートに置く方法です。`index.html`、`vendor/`、`.mjs`、`.nojekyll`、`source.zip`、`LICENSE.txt` を含めて配置してください。PDF や作業ファイルを置く必要はありません。

1. 公開用リポジトリに ZIP の**中身**を置く（ZIP 自体を置くだけでは動きません）。
2. Settings → Pages → Build and deployment で「Deploy from a branch」を選ぶ。
3. 配置したブランチの `/ (root)` を選び保存。
4. GitHub が表示する HTTPS URL を開く。`https://ユーザー名.github.io/リポジトリ名/` のサブパスに対応しています。

ソースから更新する場合は `output/releases/papermirror-browser-source.zip` の中身を専用リポジトリのルートに置きます。Settings → Pages の Source を **GitHub Actions** にして、Actions → **Publish PaperMirror browser app** → **Run workflow** を実行するとビルドして配信します。ワークフローは手動起動のみです。

この作業フォルダーには別製品もあるため、親フォルダー全体を公開しないでください。上記の専用パッケージは `web/` と必要なビルドスクリプトだけから作成し、原稿・作業履歴・ローカル設定を含めません。

## ローカルでビルド・確認

Node.js 22 以降と `tar` コマンドを使用します。Windows 付属 tar と GitHub Actions の Ubuntu の tar を想定しています。

```text
node scripts/build-web.mjs
node scripts/serve-web.mjs
```

`http://127.0.0.1:8788/papermirror-jp/` を開きます。このローカル配信は開発確認用です。公開後は利用者が起動する必要はありません。`file://` で HTML を直接開く方式には対応しません。

ビルドは npm の公式 MuPDF.js 配布物を取得し、固定 SHA-512 を検証します。インストールフックは実行しません。`web/vendor/` と `_site/` は生成物です。

## 使い方

PDF 選択 → 解析結果の確認 → 翻訳パケットを AI に渡す → 返答 JSON を検証して保存 → 日本語 PDF の生成・QA → 保存。

作業はブラウザ内の IndexedDB に保存し、変更時には revision を照合します。複数タブで古い状態を上書きしようとすると拒否します。24 時間の保存期限は起動時と開いている間の定期処理で検査します。ブラウザを閉じている間の削除時刻は保証しません。

ページを開き直して完成済みの作業を再開する場合も、原稿から PDF を再生成・再検査してから結果を表示します。保存済みの PASS だけでは検査を省略しません。

「作業ファイルを保存」で PDF と翻訳を持ち出し、別端末や Work で読み込めます。読み込み時はハッシュを検査して PDF を再解析し、翻訳も再検証します。入力ファイル内の IR・PASS・生成 PDF は信頼しません。パスワードは保存せず、解析用・出力・作業ファイル中の PDF は非暗号化です。

## 検証と制約

対応：ネイティブ文字の単段/2段組、罫線付き表の閉じたセル、図表・リンク・メタデータ・しおり、回転/切り抜きページ。停止：スキャン、3段以上、非水平文字、分離不能な数式、隠れた文字、壊れた文字マップ、文字の重なり、能動的内容など。

文字の実削除、保護トークンの出現順・数値の個数、低水準描画字形と抽出文字の照合、生成後の全文/字形在庫、保持文字の座標・字体・色、画像/描画/リンク、ページ形状、メタデータ/しおり、144 dpi の字形マスク外画素差を検査します。意味の忠実性と元字体の完全再現は保証しません。

既存の Python 版テスト用合成 PDF を再利用する検証には Python 版の開発依存が必要です。

以下の総合検証は元の開発フォルダーで実行します。静的サイト用ソース ZIP 単独で実行できるのはビルドと翻訳契約テスト（`node --test web/tests/protocol.test.mjs`）です。総合検証で使う Python 版のフィクスチャ生成器・デモ原稿は ZIP に含めていません。

```text
python scripts/browser_fixtures.py
node --test web/tests/*.test.mjs
node scripts/browser_web_acceptance.cjs
node scripts/browser_state_acceptance.cjs
```

ブラウザ検証の 2 コマンドは Playwright と Microsoft Edge が必要です。必要なら `PAPERMIRROR_PLAYWRIGHT_MODULE` でインストール済み Playwright の場所を指定してください。通常のサイト利用・ビルドには不要です。

実際のクラウド Work/Claude/Gemini、実スマートフォン、Safari/Firefox、大量の実論文、GitHub Pages の本番 URL は未検証です。ブラウザがページを停止・破棄すれば計算も止まります。再開ファイルを適宜保存してください。

## ライセンス

ブラウザ版は AGPL-3.0-or-later。MuPDF.js の元のライセンスを同梱し、公開サイトからアプリのソースコードを取得できます。ビルド時に同じ版の依存物を取得する手順と整合性ハッシュを含みます。MuPDF 本体の対応ソースは [Artifex の 1.28.1 タグ](https://github.com/ArtifexSoftware/mupdf/tree/1.28.1) を参照してください。
