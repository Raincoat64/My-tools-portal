import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {zip} from './zip.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const version='1.28.1', integrity='Gi11Ow2G1SlrXKJNZBL1eAIGFVih5+4ZKqjptamTVaj/5hnlrcVrVbyb7lHE2lfFKdxZPyv9ZtfOOq7XgjzEig==';
const archive=path.join(root,'tmp',`mupdf-${version}.tgz`);
await fs.mkdir(path.dirname(archive),{recursive:true});
let bytes;
try{bytes=await fs.readFile(archive);}catch{const response=await fetch(`https://registry.npmjs.org/mupdf/-/mupdf-${version}.tgz`);if(!response.ok)throw Error(`Download failed: ${response.status}`);bytes=Buffer.from(await response.arrayBuffer());}
if(createHash('sha512').update(bytes).digest('base64')!==integrity)throw Error('MuPDF package integrity mismatch');
await fs.writeFile(archive,bytes);
const extracted=path.join(root,'tmp','mupdf-browser');await fs.mkdir(extracted,{recursive:true});
const names=execFileSync('tar',['-tf',archive],{encoding:'utf8'}).trim().split(/\r?\n/);
if(names.some(name=>!name.startsWith('package/')||name.split('/').includes('..')||name.includes('\\')))throw Error('Unsafe archive path');
execFileSync('tar',['-xf',archive,'-C',extracted]);
const vendor=path.join(root,'web','vendor','mupdf');await fs.mkdir(vendor,{recursive:true});
for(const name of ['mupdf.js','mupdf-wasm.js','mupdf-wasm.wasm'])await fs.copyFile(path.join(extracted,'package','dist',name),path.join(vendor,name));
await fs.copyFile(path.join(extracted,'package','LICENSE'),path.join(vendor,'LICENSE'));
await fs.copyFile(path.join(extracted,'package','LICENSE'),path.join(root,'web','LICENSE.txt'));
await fs.writeFile(path.join(vendor,'package.json'),JSON.stringify({type:'module',name:'mupdf',version,license:'AGPL-3.0-or-later'}));
const wasm=await fs.readFile(path.join(vendor,'mupdf-wasm.wasm'));
await fs.writeFile(path.join(root,'web','engine-version.mjs'),`export const ENGINE=${JSON.stringify({name:'MuPDF.js',version,wasm_sha256:createHash('sha256').update(wasm).digest('hex'),npm_integrity:`sha512-${integrity}`})};\n`);
const output=path.join(root,'_site');
await fs.mkdir(output,{recursive:true});
// Only the explicit site tree is copied; uploaded files, local data and credentials are excluded.
await fs.cp(path.join(root,'web'),output,{recursive:true,filter:source=>!['tests','package.json'].includes(path.basename(source))});
await fs.copyFile(path.join(root,'web','package.json'),path.join(output,'package.json'));
await fs.writeFile(path.join(output,'.nojekyll'),'');
async function collect(directory,prefix='',exclude=new Set()){
  const result=[];
  for(const item of await fs.readdir(directory,{withFileTypes:true})){
    if(exclude.has(item.name)||item.isSymbolicLink())continue;
    const name=prefix+item.name,filename=path.join(directory,item.name);
    if(item.isDirectory())result.push(...await collect(filename,name+'/',exclude));else if(item.isFile())result.push([name,await fs.readFile(filename)]);
  }return result;
}
const sources=await collect(path.join(root,'web'),'web/',new Set(['vendor','engine-version.mjs']));
for(const name of ['scripts/build-web.mjs','scripts/zip.mjs','scripts/serve-web.mjs','scripts/browser_web_acceptance.cjs','scripts/browser_state_acceptance.cjs','.github/workflows/pages.yml','README-BROWSER.md'])sources.push([name,await fs.readFile(path.join(root,name))]);
sources.push(['.gitignore',Buffer.from('web/vendor/\nweb/engine-version.mjs\n_site/\ntmp/\noutput/\n')]);
const sourceZip=zip(sources);await fs.writeFile(path.join(output,'source.zip'),sourceZip);
const releases=path.join(root,'output','releases');await fs.mkdir(releases,{recursive:true});
await fs.writeFile(path.join(releases,'papermirror-browser-source.zip'),sourceZip);
await fs.writeFile(path.join(releases,'papermirror-pages.zip'),zip(await collect(output)));
console.log(`Static site: ${output}`);
console.log(`Release packages: ${releases}`);
