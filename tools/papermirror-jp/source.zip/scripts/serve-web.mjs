import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..','_site');
export function staticServer({base='/papermirror-jp/'}={}){
  return http.createServer(async(req,res)=>{
    const url=new URL(req.url,'http://localhost');
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
    if(url.pathname===base.slice(0,-1)){res.writeHead(302,{Location:base});res.end();return;}
    if(!url.pathname.startsWith(base)){res.writeHead(404);res.end();return;}
    let relative;try{relative=decodeURIComponent(url.pathname.slice(base.length))||'index.html';}catch{res.writeHead(400);res.end();return;}
    const filename=path.resolve(root,relative);
    if(!filename.startsWith(root+path.sep)||relative.includes('\\')){res.writeHead(403);res.end();return;}
    try{
      const bytes=await fs.readFile(filename),types={'.html':'text/html; charset=utf-8','.js':'text/javascript','.mjs':'text/javascript','.css':'text/css','.wasm':'application/wasm','.svg':'image/svg+xml','.json':'application/json','.txt':'text/plain; charset=utf-8','.zip':'application/zip'};
      res.setHeader('Content-Type',types[path.extname(filename)]||'application/octet-stream');res.setHeader('Cache-Control','no-cache');res.setHeader('X-Content-Type-Options','nosniff');res.end(req.method==='HEAD'?undefined:bytes);
    }catch{res.writeHead(404);res.end();}
  });
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  const port=Number(process.env.PAPERMIRROR_WEB_PORT||8788);staticServer().listen(port,'127.0.0.1',()=>console.log(`Static preview only: http://127.0.0.1:${port}/papermirror-jp/`));
}
