const fs=require('node:fs/promises'),path=require('node:path'),assert=require('node:assert/strict');
const {pathToFileURL}=require('node:url');
const {chromium}=require(process.env.PAPERMIRROR_PLAYWRIGHT_MODULE||'playwright');
const root=path.resolve(__dirname,'..');
(async()=>{
  const {staticServer}=await import(pathToFileURL(path.join(__dirname,'serve-web.mjs'))),server=staticServer();await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));let browser;
  try{
    browser=await chromium.launch({channel:'msedge',headless:true});const context=await browser.newContext(),page=await context.newPage();
    const url=`http://127.0.0.1:${server.address().port}/papermirror-jp/`;await page.goto(url);await page.waitForFunction(()=>!document.querySelector('#analyze-pdf').disabled);
    const source=JSON.parse(await fs.readFile(path.join(root,'output/browser-acceptance/resume.papermirror.json'),'utf8'));
    const report=await page.evaluate(async project=>{
      const store=await import('./store.mjs'),jobs=await import('./jobs.mjs'),engine=await import('./worker-client.mjs');const checks=[];
      let job=await jobs.importProject(new File([JSON.stringify(project)],'resume.json'),()=>{});job=await jobs.reviewJob(job);
      const stale=structuredClone(job),saved=await store.saveJob({...job,filename:'Updated.pdf'},job.revision);let rejected=false;
      try{await store.saveJob({...stale,filename:'Stale.pdf'},stale.revision);}catch{rejected=true;}
      if(!rejected||(await store.getJob(job.job_id)).filename!=='Updated.pdf')throw Error('Stale write was not rejected');checks.push('atomic revision check rejects stale tab writes');
      job=saved;const batch=job.batches[0],packet=await jobs.getPacket(job,batch),response={...packet.response_template,translations:batch.unit_ids.map(id=>({unit_id:id,status:job.translations[id].status,ja:job.translations[id].ja}))};
      for(const forged of [{...batch,batch_id:'invented-root'},{...batch,unit_ids:batch.unit_ids.slice(1)}]){
        for(const operation of [()=>jobs.getPacket(job,forged),()=>jobs.validateResponse(job,forged,JSON.stringify(response)),()=>jobs.retry(job,forged)]){
          rejected=false;try{await operation();}catch{rejected=true;}if(!rejected)throw Error('Forged batch accepted');
        }
      }checks.push('packet, response and retry reject invented or altered batches');
      let retryJob=await jobs.importProject(new File([JSON.stringify(project)],'retry.json'),()=>{});retryJob=await jobs.reviewJob(retryJob);retryJob=await store.saveJob({...retryJob,translations:{}},retryJob.revision);
      const firstRetry=await jobs.retry(retryJob,retryJob.batches[0]),secondRetry=await jobs.retry(firstRetry.job,firstRetry.batch);
      rejected=false;try{await jobs.retry(secondRetry.job,secondRetry.batch);}catch(e){rejected=e.message==='RETRY_LIMIT_REACHED';}if(!rejected)throw Error('Third retry accepted');await store.deleteJob(retryJob.job_id);checks.push('persisted root enforces two retries across retry chains');
      const identical=await jobs.submit(job,batch,JSON.stringify(response));if(identical.revision!==job.revision)throw Error('Idempotent response changed revision');checks.push('identical translation response is idempotent');
      const wrong=structuredClone(response);wrong.translations[0].ja+='追加';rejected=false;try{await jobs.submit(job,batch,JSON.stringify(wrong));}catch{rejected=true;}if(!rejected)throw Error('Accepted translation could be changed');checks.push('accepted translation immutable');
      const rendered=await jobs.renderJob(job,()=>{}),repeated=await jobs.renderJob(rendered,()=>{});if(repeated.revision!==rendered.revision)throw Error('Repeated render mutated PASS');checks.push('completed render is idempotent');
      const corrupted=structuredClone(rendered);corrupted.output[0]^=1;const repaired=await jobs.restoreSavedJob(corrupted,()=>{});if(repaired.output[0]!==0x25||repaired.qa.status!=='PASS'||repaired.revision<=corrupted.revision||await jobs.hash(repaired.output)!==repaired.manifest.output_sha256)throw Error('Corrupt cached PDF accepted');checks.push('modified cached output is regenerated before PASS reuse');
      const forgedJob=structuredClone(repaired);forgedJob.ir.pages[0].regions[0].action='preserve';delete forgedJob.ir.pages[0].regions[0].unit_id;
      const persistedForgery=await store.saveJob(forgedJob,repaired.revision);rejected=false;try{await jobs.restoreSavedJob(persistedForgery,()=>{});}catch{rejected=true;}if(!rejected)throw Error('Forged stored IR produced PASS');checks.push('stored IR changes cannot bypass PDF reanalysis');
      const long=new Uint8Array(job.source),running=engine.compute('render',[long,job.ir,job.translations]);await new Promise(resolve=>setTimeout(resolve,0));engine.stopWorker();let cancelled=false;try{await running;}catch(e){cancelled=e.code==='CANCELLED';}if(!cancelled)throw Error('Worker cancellation failed');checks.push('running worker cancellation rejects operation');
      const loading=engine.startWorker();engine.stopWorker();cancelled=false;try{await loading;}catch(e){cancelled=e.code==='CANCELLED';}if(!cancelled)throw Error('Initial load cancellation hung');checks.push('worker initialization cancellation rejects readiness');
      await engine.startWorker();const png=await engine.compute('preview',[job.source,1]);if(!png.length)throw Error('Worker did not recover');checks.push('worker restarts after cancellation');
      const originalNow=Date.now;Date.now=()=>job.expires_at+1;try{await store.cleanup();if(await store.getJob(job.job_id))throw Error('Expired job survived');}finally{Date.now=originalNow;}checks.push('expired IndexedDB job removed at cleanup');
      await store.deleteAll();return {checks};
    },source);
    for(const link of ['README.html','LICENSE.txt','source.zip','vendor/mupdf/mupdf-wasm.wasm']){const response=await context.request.get(url+link);assert.equal(response.status(),200,link);}report.checks.push('help, license, source and engine artifacts are accessible');
    report.checkedAt=new Date().toISOString();await fs.writeFile(path.join(root,'output/browser-acceptance/state-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));
  }finally{if(browser)await browser.close();await new Promise(resolve=>server.close(resolve));}
})().catch(e=>{console.error(e);process.exitCode=1;});
